import 'package:hse_project/controllers/my_controller.dart';
import 'package:flutter/material.dart';

class AuthLayoutController extends MyController {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();
  final scrollKey = GlobalKey();
}
