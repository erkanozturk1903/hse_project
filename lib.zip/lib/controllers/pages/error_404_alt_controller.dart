import 'package:hse_project/controllers/my_controller.dart';

class Error404AltController extends MyController {}
