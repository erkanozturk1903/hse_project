import 'package:hse_project/controllers/my_controller.dart';

class AdvancedFormsController extends MyController {
  AdvancedFormsController();
}
