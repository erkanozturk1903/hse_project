import 'package:hse_project/controllers/my_controller.dart';

class FormMaskController extends MyController {}
