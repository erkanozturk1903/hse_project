abstract class MyException implements Exception {}
